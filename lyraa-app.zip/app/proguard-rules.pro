# Proguard rules for LYRA Assistant
-keep class com.lyra.assistant.model.** { *; }
-keep class com.lyra.assistant.data.local.** { *; }
-keep class com.lyra.assistant.data.remote.** { *; }
