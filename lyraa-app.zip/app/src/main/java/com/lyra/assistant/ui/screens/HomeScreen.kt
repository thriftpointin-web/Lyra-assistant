package com.lyra.assistant.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyra.assistant.model.AiState
import com.lyra.assistant.theme.*
import com.lyra.assistant.ui.components.AnimatedAiOrb
import com.lyra.assistant.ui.viewmodel.LyraViewModel

@Composable
fun HomeScreen(
    viewModel: LyraViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToVoice: () -> Unit
) {
    val aiState by viewModel.aiState.collectAsState()
    val rmsDb by viewModel.speechRecognizer.rmsDbLevel.collectAsState()
    val isListening by viewModel.speechRecognizer.isListening.collectAsState()
    val isSpeaking by viewModel.textToSpeech.isSpeaking.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(horizontal = 24.dp)
            .statusBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(vertical = 8.dp)
        ) {
            Text(
                text = "LYRA",
                color = TextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "✦",
                color = PurpleNeon,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Text(
            text = "Your Personal AI Companion",
            color = TextSecondary,
            fontSize = 12.sp,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.weight(0.7f))

        // Central AI Orb
        AnimatedAiOrb(
            aiState = aiState,
            rmsDb = rmsDb,
            size = 230.dp,
            onClick = { viewModel.onOrbClick() }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // State indicator label
        val stateLabel = when (aiState) {
            AiState.IDLE -> "Tap orb to speak"
            AiState.LISTENING -> "Listening to Owais..."
            AiState.THINKING -> "LYRA is thinking..."
            AiState.SPEAKING -> "LYRA is speaking (Tap to stop)"
            AiState.ERROR -> "Error state"
            AiState.OFFLINE -> "Offline"
        }

        Text(
            text = stateLabel,
            color = when (aiState) {
                AiState.LISTENING -> ListeningCyan
                AiState.THINKING -> ThinkingViolet
                AiState.SPEAKING -> SpeakingPurple
                AiState.ERROR -> ErrorRed
                else -> TextSecondary
            },
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Main Greeting
        Text(
            text = "Hey Owais ❤️",
            color = TextPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "How can I help you?",
            color = TextSecondary,
            fontSize = 17.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.weight(0.8f))

        // Quick suggestion pills
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionChip(
                    text = "Physics samjhao",
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Lyra mujhe physics samjhao")
                    onNavigateToChat()
                }
                QuickActionChip(
                    text = "Mera naam kya hai?",
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Lyra mera naam kya hai?")
                    onNavigateToChat()
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionChip(
                    text = "Tumhe kisne banaya?",
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Tumhe kisne banaya?")
                    onNavigateToChat()
                }
                QuickActionChip(
                    text = "Ali ko call karo",
                    modifier = Modifier.weight(1f)
                ) {
                    viewModel.sendMessage("Ali ko call karo")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun QuickActionChip(
    text: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurface)
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}
