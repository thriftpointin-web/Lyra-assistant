package com.lyra.assistant.service.calling

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat

class CallingService(private val context: Context) {

    fun hasCallPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Executes phone call after user confirmation.
     * Uses direct ACTION_CALL if permission is granted, or falls back to ACTION_DIAL.
     */
    fun makeCall(phoneNumber: String): Boolean {
        val sanitized = phoneNumber.replace(Regex("[^0-9+]"), "")
        if (sanitized.isEmpty()) return false

        return try {
            if (hasCallPermission()) {
                val callIntent = Intent(Intent.ACTION_CALL).apply {
                    data = Uri.parse("tel:$sanitized")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
                true
            } else {
                // Safe fallback to dialer when CALL_PHONE permission is not granted
                val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                    data = Uri.parse("tel:$sanitized")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
                true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
