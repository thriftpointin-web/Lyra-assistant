package com.lyra.assistant.model

/**
 * Visual and operational states for the LYRA AI Assistant and central AI orb.
 */
enum class AiState {
    IDLE,        // Soft breathing glow
    LISTENING,   // Animated pulse / wave reacting to microphone RMS dB
    THINKING,    // Subtle orbital processing animation
    SPEAKING,    // Pulsing and reacting while LYRA delivers audio
    ERROR,       // Amber/Red alert glow
    OFFLINE      // Dimmed / disconnected indication
}
