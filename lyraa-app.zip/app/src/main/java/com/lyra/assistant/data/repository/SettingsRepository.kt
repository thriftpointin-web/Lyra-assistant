package com.lyra.assistant.data.repository

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceSettings(
    val voiceName: String = "",
    val speechSpeed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val voiceRepliesEnabled: Boolean = true
)

class SettingsRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("lyra_prefs", Context.MODE_PRIVATE)

    private val _voiceSettings = MutableStateFlow(
        VoiceSettings(
            voiceName = prefs.getString("voice_name", "") ?: "",
            speechSpeed = prefs.getFloat("speech_speed", 1.0f),
            pitch = prefs.getFloat("pitch", 1.0f),
            voiceRepliesEnabled = prefs.getBoolean("voice_replies_enabled", true)
        )
    )
    val voiceSettings: StateFlow<VoiceSettings> = _voiceSettings.asStateFlow()

    private val _backendUrl = MutableStateFlow(
        prefs.getString("backend_url", "https://ais-dev-y72cazxf44ucx4skizxy22-630603362654.asia-east1.run.app")
            ?: "https://ais-dev-y72cazxf44ucx4skizxy22-630603362654.asia-east1.run.app"
    )
    val backendUrl: StateFlow<String> = _backendUrl.asStateFlow()

    fun updateVoiceSettings(
        voiceName: String = _voiceSettings.value.voiceName,
        speed: Float = _voiceSettings.value.speechSpeed,
        pitch: Float = _voiceSettings.value.pitch,
        enabled: Boolean = _voiceSettings.value.voiceRepliesEnabled
    ) {
        val updated = VoiceSettings(voiceName, speed, pitch, enabled)
        _voiceSettings.value = updated
        prefs.edit()
            .putString("voice_name", voiceName)
            .putFloat("speech_speed", speed)
            .putFloat("pitch", pitch)
            .putBoolean("voice_replies_enabled", enabled)
            .apply()
    }

    fun updateBackendUrl(url: String) {
        val cleanUrl = url.trimEnd('/')
        _backendUrl.value = cleanUrl
        prefs.edit().putString("backend_url", cleanUrl).apply()
    }
}
