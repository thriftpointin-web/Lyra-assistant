package com.lyra.assistant.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lyra.assistant.data.local.LyraDatabase
import com.lyra.assistant.data.remote.LyraApiService
import com.lyra.assistant.data.repository.*
import com.lyra.assistant.model.*
import com.lyra.assistant.service.calling.CallingService
import com.lyra.assistant.service.intent.CommandProcessor
import com.lyra.assistant.service.permission.PermissionManager
import com.lyra.assistant.service.voice.LyraSpeechRecognizer
import com.lyra.assistant.service.voice.LyraTextToSpeech
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*

class LyraViewModel(application: Application) : AndroidViewModel(application) {

    // Repositories & Services
    private val database = LyraDatabase.getInstance(application)
    val memoryRepository = MemoryRepository(database.memoryDao())
    val settingsRepository = SettingsRepository(application)
    val contactRepository = ContactRepository(application)
    val callingService = CallingService(application)
    val permissionManager = PermissionManager(application)
    val commandProcessor = CommandProcessor()

    private val apiService = LyraApiService(settingsRepository.backendUrl.value)
    val aiRepository = AiRepository(apiService)

    // Speech & Voice Engines
    val textToSpeech: LyraTextToSpeech = LyraTextToSpeech(application) { isReady ->
        if (isReady) {
            val settings = settingsRepository.voiceSettings.value
            textToSpeech.setSpeed(settings.speechSpeed)
            textToSpeech.setPitch(settings.pitch)
            if (settings.voiceName.isNotBlank()) {
                textToSpeech.setVoice(settings.voiceName)
            }
        }
    }

    val speechRecognizer: LyraSpeechRecognizer = LyraSpeechRecognizer(
        context = application,
        onResult = { recognizedText -> handleUserSpeech(recognizedText) },
        onError = { errorMsg ->
            _aiState.value = AiState.ERROR
            _systemNotice.value = errorMsg
        }
    )

    // State Flows
    private val _aiState = MutableStateFlow(AiState.IDLE)
    val aiState: StateFlow<AiState> = _aiState.asStateFlow()

    private val _messages = MutableStateFlow<List<Message>>(
        listOf(
            Message(
                text = "Hey Owais ❤️\nMain hoon LYRA, tumhari personal AI companion. Kaise madad kar sakti hoon?",
                isUser = false
            )
        )
    )
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    val memories: StateFlow<List<MemoryItem>> = memoryRepository.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _pendingContactConfirmation = MutableStateFlow<ContactItem?>(null)
    val pendingContactConfirmation: StateFlow<ContactItem?> = _pendingContactConfirmation.asStateFlow()

    private val _pendingMultipleContacts = MutableStateFlow<Pair<String, List<ContactItem>>?>(null)
    val pendingMultipleContacts: StateFlow<Pair<String, List<ContactItem>>?> = _pendingMultipleContacts.asStateFlow()

    private val _systemNotice = MutableStateFlow<String?>(null)
    val systemNotice: StateFlow<String?> = _systemNotice.asStateFlow()

    init {
        // Sync AI orb state with speech engines
        viewModelScope.launch {
            combine(
                speechRecognizer.isListening,
                textToSpeech.isSpeaking,
                _aiState
            ) { isListening, isSpeaking, currentState ->
                when {
                    isListening -> AiState.LISTENING
                    isSpeaking -> AiState.SPEAKING
                    currentState == AiState.THINKING -> AiState.THINKING
                    currentState == AiState.ERROR -> AiState.ERROR
                    else -> AiState.IDLE
                }
            }.collect { newState ->
                if (_aiState.value != AiState.THINKING && _aiState.value != AiState.ERROR) {
                    _aiState.value = newState
                }
            }
        }
    }

    /**
     * User taps Central AI Orb:
     * If speaking -> Stop speaking (Interrupt)
     * If listening -> Stop listening
     * If idle -> Start listening
     */
    fun onOrbClick() {
        if (textToSpeech.isSpeaking.value) {
            textToSpeech.stop()
            _aiState.value = AiState.IDLE
            return
        }

        if (speechRecognizer.isListening.value) {
            speechRecognizer.stopListening()
            _aiState.value = AiState.IDLE
        } else {
            textToSpeech.stop()
            _aiState.value = AiState.LISTENING
            speechRecognizer.startListening()
        }
    }

    fun handleUserSpeech(text: String) {
        if (text.isBlank()) return
        sendMessage(text)
    }

    fun sendMessage(inputText: String) {
        val cleanInput = inputText.trim()
        if (cleanInput.isEmpty()) return

        // Add user message to chat UI
        val userMsg = Message(text = cleanInput, isUser = true)
        _messages.value = _messages.value + userMsg

        // Intercept via Intent / Command layer
        val command = commandProcessor.process(cleanInput)
        when (command) {
            is UserCommand.WhatIsMyName -> {
                respondDirectly("Tumhara naam Owais hai ❤️")
            }
            is UserCommand.WhoMadeYou -> {
                respondDirectly("Mujhe Owais ne banaya hai.")
            }
            is UserCommand.Remember -> {
                viewModelScope.launch {
                    memoryRepository.saveMemory(command.key, command.value)
                    respondDirectly("Maine yaad rakh liya hai: \"${command.value}\" ❤️")
                }
            }
            is UserCommand.Forget -> {
                viewModelScope.launch {
                    respondDirectly("Ji, maine is baat ko bhula diya hai.")
                }
            }
            is UserCommand.ShowMemories -> {
                val current = memories.value
                val text = if (current.isEmpty()) {
                    "Abhi koi memories saved nahi hain."
                } else {
                    "Aapki saved memories:\n" + current.joinToString("\n") { "• ${it.value}" }
                }
                respondDirectly(text)
            }
            is UserCommand.ClearMemories -> {
                viewModelScope.launch {
                    memoryRepository.clearAll()
                    respondDirectly("Saari extra memories clear kar di gayi hain.")
                }
            }
            is UserCommand.CallContact -> {
                executeCallIntent(command.contactName)
            }
            is UserCommand.OpenApp -> {
                respondDirectly("App launch request (${command.appTarget}) process ki ja rahi hai.")
            }
            is UserCommand.AdjustVoice -> {
                val current = settingsRepository.voiceSettings.value
                val newSpeed = (current.speechSpeed + (command.speedDelta ?: 0f)).coerceIn(0.5f, 2.0f)
                settingsRepository.updateVoiceSettings(speed = newSpeed)
                textToSpeech.setSpeed(newSpeed)
                respondDirectly("Maine apni bolne ki raftaar adjust kar li hai.")
            }
            is UserCommand.NormalChat -> {
                executeAiChatStreaming(cleanInput)
            }
            else -> {
                executeAiChatStreaming(cleanInput)
            }
        }
    }

    private fun respondDirectly(replyText: String) {
        val lyraMsg = Message(text = replyText, isUser = false)
        _messages.value = _messages.value + lyraMsg

        if (settingsRepository.voiceSettings.value.voiceRepliesEnabled) {
            _aiState.value = AiState.SPEAKING
            textToSpeech.speak(replyText)
        } else {
            _aiState.value = AiState.IDLE
        }
    }

    private fun executeCallIntent(nameQuery: String) {
        val result = contactRepository.findContacts(nameQuery)
        when (result) {
            is ContactSearchResult.PermissionDenied -> {
                val msg = "Contacts search karne ke liye READ_CONTACTS permission darkar hai."
                respondDirectly(msg)
            }
            is ContactSearchResult.NotFound -> {
                val msg = "Mujhe $nameQuery naam ka contact nahi mila."
                respondDirectly(msg)
            }
            is ContactSearchResult.SuccessSingle -> {
                _pendingContactConfirmation.value = result.contact
                val promptText = "${result.contact.name} naam ka contact mila hai. Kya main call karun?"
                val lyraMsg = Message(text = promptText, isUser = false)
                _messages.value = _messages.value + lyraMsg
                if (settingsRepository.voiceSettings.value.voiceRepliesEnabled) {
                    textToSpeech.speak(promptText)
                }
            }
            is ContactSearchResult.SuccessMultiple -> {
                _pendingMultipleContacts.value = Pair(nameQuery, result.contacts)
                val promptText = "$nameQuery naam ke multiple contacts mile hain. Kisko call lagani hai?"
                val lyraMsg = Message(text = promptText, isUser = false)
                _messages.value = _messages.value + lyraMsg
                if (settingsRepository.voiceSettings.value.voiceRepliesEnabled) {
                    textToSpeech.speak(promptText)
                }
            }
        }
    }

    fun confirmCall(contact: ContactItem) {
        _pendingContactConfirmation.value = null
        _pendingMultipleContacts.value = null
        val success = callingService.makeCall(contact.phoneNumber)
        val text = if (success) "Calling ${contact.name} (${contact.phoneNumber})..." else "Could not launch call."
        val lyraMsg = Message(text = text, isUser = false)
        _messages.value = _messages.value + lyraMsg
    }

    fun dismissCallDialog() {
        _pendingContactConfirmation.value = null
        _pendingMultipleContacts.value = null
        val lyraMsg = Message(text = "Call cancel kar di gayi.", isUser = false)
        _messages.value = _messages.value + lyraMsg
    }

    private fun executeAiChatStreaming(prompt: String) {
        _aiState.value = AiState.THINKING

        val currentMessages = _messages.value
        val streamingMessageId = UUID.randomUUID().toString()

        val initialLyraMsg = Message(
            id = streamingMessageId,
            text = "",
            isUser = false,
            isStreaming = true
        )
        _messages.value = currentMessages + initialLyraMsg

        val spokenSentences = mutableSetOf<String>()
        var accumulatedBuffer = ""
        var fullText = ""

        viewModelScope.launch {
            try {
                aiRepository.streamResponse(currentMessages, memories.value).collect { chunk ->
                    _aiState.value = AiState.SPEAKING
                    fullText += chunk
                    accumulatedBuffer += chunk

                    // Update UI streaming message
                    _messages.value = _messages.value.map { msg ->
                        if (msg.id == streamingMessageId) msg.copy(text = fullText) else msg
                    }

                    // Low-latency early TTS: Speak sentence boundaries as they stream
                    if (settingsRepository.voiceSettings.value.voiceRepliesEnabled) {
                        val sentenceDelimiters = listOf(".", "!", "?", "\n", "।")
                        for (delim in sentenceDelimiters) {
                            if (accumulatedBuffer.contains(delim)) {
                                val parts = accumulatedBuffer.split(delim)
                                if (parts.size > 1) {
                                    val sentenceToSpeak = parts[0].trim() + delim
                                    if (sentenceToSpeak.isNotBlank() && !spokenSentences.contains(sentenceToSpeak)) {
                                        spokenSentences.add(sentenceToSpeak)
                                        textToSpeech.speak(sentenceToSpeak, android.speech.tts.TextToSpeech.QUEUE_ADD)
                                        accumulatedBuffer = parts.subList(1, parts.size).joinToString(delim)
                                    }
                                }
                            }
                        }
                    }
                }

                // Finalize streaming
                _messages.value = _messages.value.map { msg ->
                    if (msg.id == streamingMessageId) msg.copy(isStreaming = false) else msg
                }

                // Speak any remaining leftover text in buffer
                if (settingsRepository.voiceSettings.value.voiceRepliesEnabled && accumulatedBuffer.trim().isNotEmpty()) {
                    if (!spokenSentences.contains(accumulatedBuffer.trim())) {
                        textToSpeech.speak(accumulatedBuffer.trim(), android.speech.tts.TextToSpeech.QUEUE_ADD)
                    }
                }

                if (!textToSpeech.isSpeaking.value) {
                    _aiState.value = AiState.IDLE
                }
            } catch (e: Exception) {
                _aiState.value = AiState.ERROR
                val errorNotice = "AI Error: ${e.message ?: "Failed to connect to LYRA backend"}"
                _messages.value = _messages.value.map { msg ->
                    if (msg.id == streamingMessageId) {
                        msg.copy(
                            text = if (fullText.isNotBlank()) fullText else errorNotice,
                            isStreaming = false,
                            isError = true
                        )
                    } else msg
                }
            }
        }
    }

    fun clearChatHistory() {
        _messages.value = listOf(
            Message(
                text = "Chat history cleared. Hey Owais ❤️ How can I help you?",
                isUser = false
            )
        )
    }

    fun deleteMessage(id: String) {
        _messages.value = _messages.value.filter { it.id != id }
    }

    fun retryLastMessage() {
        val lastUserMessage = _messages.value.lastOrNull { it.isUser }
        if (lastUserMessage != null) {
            sendMessage(lastUserMessage.text)
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.destroy()
        textToSpeech.shutdown()
    }
}
