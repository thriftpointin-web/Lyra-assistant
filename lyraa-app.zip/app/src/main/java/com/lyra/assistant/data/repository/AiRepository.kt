package com.lyra.assistant.data.repository

import com.lyra.assistant.data.remote.LyraApiService
import com.lyra.assistant.model.MemoryItem
import com.lyra.assistant.model.Message
import kotlinx.coroutines.flow.Flow

class AiRepository(
    private val apiService: LyraApiService
) {
    fun streamResponse(
        messages: List<Message>,
        memories: List<MemoryItem>
    ): Flow<String> {
        return apiService.streamChat(messages, memories)
    }

    fun updateBackendUrl(url: String) {
        apiService.updateBaseUrl(url)
    }

    fun getBackendUrl(): String = apiService.getBaseUrl()
}
