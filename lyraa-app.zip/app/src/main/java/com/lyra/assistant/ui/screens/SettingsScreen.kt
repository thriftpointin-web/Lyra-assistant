package com.lyra.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyra.assistant.service.permission.AppPermission
import com.lyra.assistant.theme.*
import com.lyra.assistant.ui.viewmodel.LyraViewModel

@Composable
fun SettingsScreen(viewModel: LyraViewModel) {
    val scrollState = rememberScrollState()
    val voiceSettings by viewModel.settingsRepository.voiceSettings.collectAsState()
    val backendUrl by viewModel.settingsRepository.backendUrl.collectAsState()
    val availableVoices by viewModel.textToSpeech.availableVoices.collectAsState()

    var showBackendDialog by remember { mutableStateOf(false) }
    var tempBackendUrl by remember { mutableStateOf(backendUrl) }
    var expandedVoiceMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Title
        Text(
            text = "Settings",
            color = TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "AI, Voice & System Configurations",
            color = TextSecondary,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // SECTION: AI BRAIN
        SettingsSectionHeader("AI BRAIN & BACKEND")
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AI Provider", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("Gemini 3.8 Flash (via Secure Server)", color = TextSecondary, fontSize = 12.sp)
                    }
                    Text("Connected", color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Divider(color = DarkBorder, thickness = 0.8.dp)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            tempBackendUrl = backendUrl
                            showBackendDialog = true
                        },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Backend URL", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(backendUrl, color = PurpleNeon, fontSize = 12.sp, maxLines = 1)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECTION: VOICE ASSISTANT
        SettingsSectionHeader("VOICE & SPEECH")
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Voice Replies Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Voice Replies", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("Speak answers aloud automatically", color = TextSecondary, fontSize = 12.sp)
                    }
                    Switch(
                        checked = voiceSettings.voiceRepliesEnabled,
                        onCheckedChange = { viewModel.settingsRepository.updateVoiceSettings(enabled = it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PurpleNeon
                        )
                    )
                }

                Divider(color = DarkBorder, thickness = 0.8.dp)

                // Voice selection
                Box {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expandedVoiceMenu = true },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Assistant Voice", color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text(
                                text = if (voiceSettings.voiceName.isNotBlank()) voiceSettings.voiceName else "Default Natural Female",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                    }

                    DropdownMenu(
                        expanded = expandedVoiceMenu,
                        onDismissRequest = { expandedVoiceMenu = false },
                        modifier = Modifier.background(DarkSurfaceElevated)
                    ) {
                        if (availableVoices.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("System Default Voice", color = TextPrimary) },
                                onClick = {
                                    viewModel.settingsRepository.updateVoiceSettings(voiceName = "")
                                    expandedVoiceMenu = false
                                }
                            )
                        } else {
                            availableVoices.take(10).forEach { v ->
                                DropdownMenuItem(
                                    text = { Text("${v.name} (${v.locale})", color = TextPrimary, fontSize = 13.sp) },
                                    onClick = {
                                        viewModel.settingsRepository.updateVoiceSettings(voiceName = v.name)
                                        viewModel.textToSpeech.setVoice(v.name)
                                        expandedVoiceMenu = false
                                    }
                                )
                            }
                        }
                    }
                }

                Divider(color = DarkBorder, thickness = 0.8.dp)

                // Speech Speed Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Speed", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("${String.format("%.1f", voiceSettings.speechSpeed)}x", color = PurpleNeon, fontSize = 13.sp)
                    }
                    Slider(
                        value = voiceSettings.speechSpeed,
                        onValueChange = {
                            viewModel.settingsRepository.updateVoiceSettings(speed = it)
                            viewModel.textToSpeech.setSpeed(it)
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = PurpleNeon,
                            activeTrackColor = PurpleNeon
                        )
                    )
                }

                // Speech Pitch Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Voice Pitch", color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("${String.format("%.1f", voiceSettings.pitch)}x", color = PurpleNeon, fontSize = 13.sp)
                    }
                    Slider(
                        value = voiceSettings.pitch,
                        onValueChange = {
                            viewModel.settingsRepository.updateVoiceSettings(pitch = it)
                            viewModel.textToSpeech.setPitch(it)
                        },
                        valueRange = 0.5f..2.0f,
                        steps = 5,
                        colors = SliderDefaults.colors(
                            thumbColor = PurpleNeon,
                            activeTrackColor = PurpleNeon
                        )
                    )
                }

                // Test Voice Button
                OutlinedButton(
                    onClick = {
                        viewModel.textToSpeech.speak("Namaste Owais! Main hoon LYRA. Meri aawaz kaisi lag rahi hai?")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PurpleNeon)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Test Voice Preview")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECTION: PERMISSIONS
        SettingsSectionHeader("SYSTEM PERMISSIONS")
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                AppPermission.values().forEach { perm ->
                    val isGranted = viewModel.permissionManager.isGranted(perm)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(perm.title, color = TextPrimary, fontWeight = FontWeight.Medium)
                            Text(perm.rationale, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        Text(
                            text = if (isGranted) "Granted" else "Required",
                            color = if (isGranted) SuccessGreen else ErrorRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Divider(color = DarkBorder, thickness = 0.8.dp)
                }

                Button(
                    onClick = { viewModel.permissionManager.openAppSettings() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated)
                ) {
                    Text("Manage in Android Settings", color = TextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECTION: ABOUT
        SettingsSectionHeader("ABOUT LYRA")
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Application", color = TextSecondary, fontSize = 13.sp)
                    Text("LYRA ✦", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Version", color = TextSecondary, fontSize = 13.sp)
                    Text("1.0.0 (Production)", color = TextPrimary)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Configured Owner", color = TextSecondary, fontSize = 13.sp)
                    Text("Owais", color = PurpleNeon, fontWeight = FontWeight.Bold)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Architecture", color = TextSecondary, fontSize = 13.sp)
                    Text("MVVM + Room + OkHttp SSE", color = TextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }

    if (showBackendDialog) {
        AlertDialog(
            onDismissRequest = { showBackendDialog = false },
            title = { Text("Configure AI Backend URL", color = TextPrimary) },
            text = {
                OutlinedTextField(
                    value = tempBackendUrl,
                    onValueChange = { tempBackendUrl = it },
                    label = { Text("Backend Base URL") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = PurpleNeon
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.settingsRepository.updateBackendUrl(tempBackendUrl)
                        viewModel.aiRepository.updateBackendUrl(tempBackendUrl)
                        showBackendDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurpleNeon)
                ) {
                    Text("Update")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBackendDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = DarkSurfaceElevated
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        color = TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
    )
}
