package com.lyra.assistant.model

data class MemoryItem(
    val id: Long = 0,
    val key: String,
    val value: String,
    val timestamp: Long = System.currentTimeMillis()
)
