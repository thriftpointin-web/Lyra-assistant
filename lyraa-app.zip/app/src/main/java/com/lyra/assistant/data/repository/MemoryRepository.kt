package com.lyra.assistant.data.repository

import com.lyra.assistant.data.local.MemoryDao
import com.lyra.assistant.data.local.MemoryEntity
import com.lyra.assistant.model.MemoryItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MemoryRepository(
    private val memoryDao: MemoryDao,
    private val externalScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    init {
        // Ensure default core identity for Owais is seeded if empty
        externalScope.launch {
            if (memoryDao.countMemories() == 0) {
                memoryDao.insertMemory(
                    MemoryEntity(key = "user_name", value = "Owais")
                )
                memoryDao.insertMemory(
                    MemoryEntity(key = "creator", value = "Owais")
                )
            }
        }
    }

    fun getAllMemories(): Flow<List<MemoryItem>> {
        return memoryDao.getAllMemories().map { entities ->
            entities.map { it.toMemoryItem() }
        }
    }

    suspend fun getMemory(key: String): MemoryItem? {
        return memoryDao.getMemoryByKey(key)?.toMemoryItem()
    }

    suspend fun saveMemory(key: String, value: String): Long {
        return memoryDao.insertMemory(
            MemoryEntity(key = key, value = value)
        )
    }

    suspend fun deleteMemory(id: Long) {
        memoryDao.deleteMemoryById(id)
    }

    suspend fun deleteMemoryByKey(key: String) {
        memoryDao.deleteMemoryByKey(key)
    }

    suspend fun clearAll() {
        memoryDao.clearAllMemories()
        // Re-seed default owner so Owais identity persists
        memoryDao.insertMemory(MemoryEntity(key = "user_name", value = "Owais"))
        memoryDao.insertMemory(MemoryEntity(key = "creator", value = "Owais"))
    }
}
