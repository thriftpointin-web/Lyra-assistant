package com.lyra.assistant.model

sealed class UserCommand {
    data class NormalChat(val query: String) : UserCommand()
    data class Remember(val key: String, val value: String) : UserCommand()
    data class Forget(val query: String) : UserCommand()
    object ShowMemories : UserCommand()
    object ClearMemories : UserCommand()
    object WhoMadeYou : UserCommand()
    object WhatIsMyName : UserCommand()
    data class CallContact(val contactName: String) : UserCommand()
    data class OpenApp(val appTarget: String) : UserCommand()
    data class AdjustVoice(val speedDelta: Float? = null, val pitchDelta: Float? = null) : UserCommand()
    object Unknown : UserCommand()
}
