package com.lyra.assistant.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lyra.assistant.model.AiState
import com.lyra.assistant.theme.*

@Composable
fun AnimatedAiOrb(
    aiState: AiState,
    rmsDb: Float = 0f,
    size: Dp = 200.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbInfinite")

    // Idle breathing pulse
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "IdlePulse"
    )

    // Thinking rotation
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    // Speaking vibration
    val speakingJitter by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "SpeakingJitter"
    )

    val scale = when (aiState) {
        AiState.IDLE -> idlePulse
        AiState.LISTENING -> (1.0f + (rmsDb.coerceIn(0f, 10f) * 0.04f)).coerceIn(1.0f, 1.4f)
        AiState.THINKING -> 1.0f
        AiState.SPEAKING -> speakingJitter
        AiState.ERROR -> 0.95f
        AiState.OFFLINE -> 0.85f
    }

    val primaryGlow = when (aiState) {
        AiState.IDLE -> PurpleNeon
        AiState.LISTENING -> ListeningCyan
        AiState.THINKING -> ThinkingViolet
        AiState.SPEAKING -> SpeakingPurple
        AiState.ERROR -> ErrorRed
        AiState.OFFLINE -> TextMuted
    }

    val secondaryGlow = when (aiState) {
        AiState.IDLE -> BlueNeon
        AiState.LISTENING -> PurpleNeon
        AiState.THINKING -> CyanAccent
        AiState.SPEAKING -> PinkNeon
        AiState.ERROR -> Color(0xFFEF4444)
        AiState.OFFLINE -> Color(0xFF334155)
    }

    Box(
        modifier = Modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2f) * 0.55f * scale

            // 1. Outer ambient glow ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = 0.35f),
                        secondaryGlow.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.6f
                ),
                radius = baseRadius * 1.6f,
                center = center
            )

            // 2. Orbital wave rings (LISTENING / THINKING)
            if (aiState == AiState.LISTENING || aiState == AiState.THINKING) {
                drawCircle(
                    color = primaryGlow.copy(alpha = 0.4f),
                    radius = baseRadius * 1.25f,
                    center = center,
                    style = Stroke(width = 2.5f)
                )
                drawCircle(
                    color = secondaryGlow.copy(alpha = 0.25f),
                    radius = baseRadius * 1.45f,
                    center = center,
                    style = Stroke(width = 1.5f)
                )
            }

            // 3. Core glowing sphere gradient
            val gradientBrush = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.9f),
                    secondaryGlow.copy(alpha = 0.85f),
                    primaryGlow,
                    VioletDeep
                ),
                center = Offset(center.x - baseRadius * 0.25f, center.y - baseRadius * 0.3f),
                radius = baseRadius
            )

            drawCircle(
                brush = gradientBrush,
                radius = baseRadius,
                center = center
            )

            // 4. Specular core highlight
            drawCircle(
                color = Color.White.copy(alpha = 0.75f),
                radius = baseRadius * 0.22f,
                center = Offset(center.x - baseRadius * 0.3f, center.y - baseRadius * 0.35f)
            )
        }
    }
}
