package com.lyra.assistant.theme

import androidx.compose.ui.graphics.Color

// Futuristic Deep Dark Canvas
val ObsidianBg = Color(0xFF07060D)
val DarkSurface = Color(0xFF100E1F)
val DarkSurfaceElevated = Color(0xFF181530)
val DarkBorder = Color(0xFF262248)

// Neon & Soft Glow Accents
val PurpleNeon = Color(0xFFA855F7)
val PurpleGlow = Color(0xFF9333EA)
val VioletDeep = Color(0xFF7C3AED)
val BlueNeon = Color(0xFF38BDF8)
val CyanAccent = Color(0xFF06B6D4)
val PinkNeon = Color(0xFFEC4899)

// State Colors
val ListeningCyan = Color(0xFF22D3EE)
val ThinkingViolet = Color(0xFFA78BFA)
val SpeakingPurple = Color(0xFFC084FC)
val ErrorRed = Color(0xFFF43F5E)
val SuccessGreen = Color(0xFF10B981)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
