package com.lyra.assistant.service.intent

import com.lyra.assistant.model.UserCommand
import java.util.regex.Pattern

class CommandProcessor {

    /**
     * Parses the user's natural language input (English, Hindi, Hinglish)
     * and categorizes it into a discrete command or regular AI chat.
     */
    fun process(rawInput: String): UserCommand {
        val input = rawInput.trim()
        if (input.isEmpty()) return UserCommand.Unknown

        val lower = input.lowercase()

        // 1. Who made you / Creator check
        if (lower.contains("who made you") ||
            lower.contains("who created you") ||
            lower.contains("kisne banaya") ||
            lower.contains("tumhe kisne banaya") ||
            lower.contains("who is your creator") ||
            lower.contains("who built you") ||
            lower.contains("tumhara creator kaun hai")
        ) {
            return UserCommand.WhoMadeYou
        }

        // 2. What is my name / User identity check
        if (lower.contains("what is my name") ||
            lower.contains("what's my name") ||
            lower.contains("mera naam kya hai") ||
            lower.contains("mera naam batao") ||
            lower.contains("do you know my name") ||
            lower.contains("who am i") ||
            lower.contains("main kaun hoon")
        ) {
            return UserCommand.WhatIsMyName
        }

        // 3. Explicit calling commands (English & Hinglish)
        // e.g. "Call Ali", "Ali ko call karo", "Phone Ali", "Make a call to Ali"
        val callRegex1 = Pattern.compile("^(?:please\\s+)?(?:call|phone|ring)\\s+([a-zA-Z0-9\\s]+)$", Pattern.CASE_INSENSITIVE)
        val callRegex2 = Pattern.compile("^([a-zA-Z0-9\\s]+)\\s+(?:ko\\s+)?(?:call|phone)\\s+(?:karo|lagao|karna)$", Pattern.CASE_INSENSITIVE)
        val callRegex3 = Pattern.compile("^(?:call|phone)\\s+(?:karo|lagao)\\s+([a-zA-Z0-9\\s]+)$", Pattern.CASE_INSENSITIVE)

        val m1 = callRegex1.matcher(input)
        if (m1.find()) {
            val name = m1.group(1)?.trim() ?: ""
            if (name.isNotEmpty() && !name.contains("me", ignoreCase = true)) {
                return UserCommand.CallContact(name)
            }
        }

        val m2 = callRegex2.matcher(input)
        if (m2.find()) {
            val name = m2.group(1)?.trim() ?: ""
            if (name.isNotEmpty()) {
                return UserCommand.CallContact(name)
            }
        }

        val m3 = callRegex3.matcher(input)
        if (m3.find()) {
            val name = m3.group(1)?.trim() ?: ""
            if (name.isNotEmpty()) {
                return UserCommand.CallContact(name)
            }
        }

        // 4. Memory commands: Remember
        // "Remember that my car is red", "Isse yaad rakhna mera password 1234", "Lyra, mera naam Owais hai, yaad rakhna"
        if (lower.startsWith("remember that") || lower.startsWith("remember ") || lower.contains("yaad rakhna")) {
            var content = input
                .replace("(?i)^remember\\s+that\\s+".toRegex(), "")
                .replace("(?i)^remember\\s+".toRegex(), "")
                .replace("(?i),?\\s*yaad\\s+rakhna.*$".toRegex(), "")
                .replace("(?i)^isse\\s+yaad\\s+rakhna\\s*".toRegex(), "")
                .trim()

            if (content.isNotEmpty()) {
                return UserCommand.Remember(key = "note_${System.currentTimeMillis() % 10000}", value = content)
            }
        }

        // 5. Memory commands: Forget
        // "Forget that", "Ye baat bhool jao", "Delete that memory"
        if (lower.contains("forget that") ||
            lower.contains("bhool jao") ||
            lower.contains("ye baat bhool jao") ||
            lower.contains("forget my")
        ) {
            return UserCommand.Forget(input)
        }

        // 6. Memory commands: Show / Clear memories
        if (lower.contains("show my memories") ||
            lower.contains("show memories") ||
            lower.contains("meri memories dikhao") ||
            lower.contains("kya yaad hai")
        ) {
            return UserCommand.ShowMemories
        }

        if (lower.contains("clear my memories") ||
            lower.contains("delete all memories") ||
            lower.contains("saari memories delete karo") ||
            lower.contains("clear memories")
        ) {
            return UserCommand.ClearMemories
        }

        // 7. Open apps
        val openAppRegex = Pattern.compile("^(?:open|launch|kholo)\\s+([a-zA-Z0-9]+)$", Pattern.CASE_INSENSITIVE)
        val mOpen = openAppRegex.matcher(input)
        if (mOpen.find()) {
            val app = mOpen.group(1)?.trim() ?: ""
            return UserCommand.OpenApp(app)
        }

        // 8. Voice adjustment
        if (lower.contains("speak slower") || lower.contains("thoda aahista bolo")) {
            return UserCommand.AdjustVoice(speedDelta = -0.2f)
        }
        if (lower.contains("speak faster") || lower.contains("thoda tez bolo")) {
            return UserCommand.AdjustVoice(speedDelta = 0.2f)
        }

        // Default to normal rich conversational AI
        return UserCommand.NormalChat(input)
    }
}
