package com.lyra.assistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.lyra.assistant.model.MemoryItem

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String,
    val value: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toMemoryItem(): MemoryItem = MemoryItem(
        id = id,
        key = key,
        value = value,
        timestamp = timestamp
    )
}
