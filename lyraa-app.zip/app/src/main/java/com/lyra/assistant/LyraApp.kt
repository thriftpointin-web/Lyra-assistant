package com.lyra.assistant

import android.app.Application
import com.lyra.assistant.data.local.LyraDatabase

class LyraApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Pre-initialize Room Database singleton
        LyraDatabase.getInstance(this)
    }
}
