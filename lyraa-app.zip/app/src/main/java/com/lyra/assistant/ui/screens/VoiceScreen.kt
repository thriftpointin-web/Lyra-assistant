package com.lyra.assistant.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyra.assistant.model.AiState
import com.lyra.assistant.theme.*
import com.lyra.assistant.ui.components.AnimatedAiOrb
import com.lyra.assistant.ui.viewmodel.LyraViewModel

@Composable
fun VoiceScreen(viewModel: LyraViewModel) {
    val aiState by viewModel.aiState.collectAsState()
    val rmsDb by viewModel.speechRecognizer.rmsDbLevel.collectAsState()
    val partialText by viewModel.speechRecognizer.partialText.collectAsState()
    val isListening by viewModel.speechRecognizer.isListening.collectAsState()
    val isSpeaking by viewModel.textToSpeech.isSpeaking.collectAsState()
    val messages by viewModel.messages.collectAsState()

    val lastLyraMessage = remember(messages) {
        messages.lastOrNull { !it.isUser }?.text ?: ""
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Voice Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Voice Assistant",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            // Mic Active Badge
            if (isListening) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(ListeningCyan.copy(alpha = 0.2f))
                        .border(1.dp, ListeningCyan, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "● MIC ACTIVE",
                        color = ListeningCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(0.5f))

        // Large Orb
        AnimatedAiOrb(
            aiState = aiState,
            rmsDb = rmsDb,
            size = 260.dp,
            onClick = { viewModel.onOrbClick() }
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Dynamic State Badge
        val stateText = when (aiState) {
            AiState.IDLE -> "Tap mic to speak with LYRA"
            AiState.LISTENING -> "Listening to your voice..."
            AiState.THINKING -> "Processing response..."
            AiState.SPEAKING -> "LYRA is speaking..."
            AiState.ERROR -> "Voice system alert"
            AiState.OFFLINE -> "Offline mode"
        }

        Text(
            text = stateText,
            color = when (aiState) {
                AiState.LISTENING -> ListeningCyan
                AiState.THINKING -> ThinkingViolet
                AiState.SPEAKING -> SpeakingPurple
                AiState.ERROR -> ErrorRed
                else -> TextSecondary
            },
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Live Speech Subtitles / Transcript Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 100.dp, max = 160.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(DarkSurface)
                .border(1.dp, DarkBorder, RoundedCornerShape(18.dp))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isListening && partialText.isNotBlank()) {
                Text(
                    text = "\"$partialText\"",
                    color = ListeningCyan,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            } else if (isSpeaking && lastLyraMessage.isNotBlank()) {
                Text(
                    text = lastLyraMessage,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = "Try saying:\n\"Lyra, mera naam kya hai?\" or \"Ali ko call karo\"",
                    color = TextMuted,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.weight(0.5f))

        // Big Mic / Stop Button
        IconButton(
            onClick = { viewModel.onOrbClick() },
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(if (isListening || isSpeaking) ErrorRed else PurpleNeon)
        ) {
            Icon(
                imageVector = if (isListening || isSpeaking) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = "Voice action",
                tint = Color.White,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (isSpeaking) "Tap to interrupt" else if (isListening) "Tap to finish" else "Tap to start voice",
            color = TextSecondary,
            fontSize = 13.sp
        )
    }
}
