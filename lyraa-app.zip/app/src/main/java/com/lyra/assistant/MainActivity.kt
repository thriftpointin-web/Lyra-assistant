package com.lyra.assistant

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import com.lyra.assistant.theme.LyraTheme
import com.lyra.assistant.theme.ObsidianBg
import com.lyra.assistant.ui.components.BottomNavBar
import com.lyra.assistant.ui.components.MultipleContactsSelectionDialog
import com.lyra.assistant.ui.components.NavTab
import com.lyra.assistant.ui.components.SingleContactConfirmationDialog
import com.lyra.assistant.ui.screens.*
import com.lyra.assistant.ui.viewmodel.LyraViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LyraViewModel by viewModels()

    // Permission request launcher
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Handle permissions results gracefully without crashing
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // Request audio recording & contact permissions upon initial launch
        requestPermissionsLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS
            )
        )

        setContent {
            LyraTheme {
                var selectedTab by remember { mutableStateOf(NavTab.HOME) }
                val singleContact by viewModel.pendingContactConfirmation.collectAsState()
                val multiContacts by viewModel.pendingMultipleContacts.collectAsState()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ObsidianBg),
                    bottomBar = {
                        BottomNavBar(
                            selectedTab = selectedTab,
                            onTabSelected = { selectedTab = it }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            NavTab.HOME -> HomeScreen(
                                viewModel = viewModel,
                                onNavigateToChat = { selectedTab = NavTab.CHAT },
                                onNavigateToVoice = { selectedTab = NavTab.VOICE }
                            )
                            NavTab.CHAT -> ChatScreen(viewModel = viewModel)
                            NavTab.VOICE -> VoiceScreen(viewModel = viewModel)
                            NavTab.MEMORY -> MemoryScreen(viewModel = viewModel)
                            NavTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }

                        // Dialog for single contact call confirmation
                        singleContact?.let { contact ->
                            SingleContactConfirmationDialog(
                                contact = contact,
                                onConfirm = { viewModel.confirmCall(contact) },
                                onDismiss = { viewModel.dismissCallDialog() }
                            )
                        }

                        // Dialog for multiple contacts selection
                        multiContacts?.let { (nameQuery, contacts) ->
                            MultipleContactsSelectionDialog(
                                contactName = nameQuery,
                                contacts = contacts,
                                onSelectContact = { chosen ->
                                    viewModel.confirmCall(chosen)
                                },
                                onDismiss = { viewModel.dismissCallDialog() }
                            )
                        }
                    }
                }
            }
        }
    }
}
