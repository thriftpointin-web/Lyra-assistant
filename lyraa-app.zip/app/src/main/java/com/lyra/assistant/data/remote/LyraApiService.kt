package com.lyra.assistant.data.remote

import com.google.gson.Gson
import com.lyra.assistant.model.MemoryItem
import com.lyra.assistant.model.Message
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources
import java.util.concurrent.TimeUnit

data class ChatStreamRequest(
    val messages: List<ChatMessagePayload>,
    val memories: List<ChatMemoryPayload>,
    val userLanguage: String = "auto"
)

data class ChatMessagePayload(
    val role: String,
    val content: String
)

data class ChatMemoryPayload(
    val key: String,
    val value: String
)

data class StreamChunk(
    val text: String? = null,
    val error: String? = null
)

class LyraApiService(
    private var baseUrl: String = "https://ais-dev-y72cazxf44ucx4skizxy22-630603362654.asia-east1.run.app"
) {
    private val gson = Gson()
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    fun updateBaseUrl(newUrl: String) {
        baseUrl = newUrl.trimEnd('/')
    }

    fun getBaseUrl(): String = baseUrl

    /**
     * Streams AI tokens via Server-Sent Events (SSE) from the secure backend.
     * Emits token chunks immediately to enable low-latency UI and early TTS.
     */
    fun streamChat(
        messages: List<Message>,
        memories: List<MemoryItem>
    ): Flow<String> = callbackFlow {
        val payload = ChatStreamRequest(
            messages = messages.map {
                ChatMessagePayload(
                    role = if (it.isUser) "user" else "model",
                    content = it.text
                )
            },
            memories = memories.map {
                ChatMemoryPayload(key = it.key, value = it.value)
            }
        )

        val jsonBody = gson.toJson(payload)
        val request = Request.Builder()
            .url("$baseUrl/api/chat/stream")
            .header("Accept", "text/event-stream")
            .header("Content-Type", "application/json")
            .post(jsonBody.toRequestBody("application/json".toMediaType()))
            .build()

        val eventSourceFactory = EventSources.createFactory(okHttpClient)
        var eventSource: EventSource? = null

        val listener = object : EventSourceListener() {
            override fun onOpen(eventSource: EventSource, response: Response) {
                // Connection established
            }

            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data == "[DONE]") {
                    close()
                    return
                }
                try {
                    val chunk = gson.fromJson(data, StreamChunk::class.java)
                    if (chunk.error != null) {
                        trySend(chunk.error)
                        close()
                    } else if (!chunk.text.isNullOrEmpty()) {
                        trySend(chunk.text)
                    }
                } catch (e: Exception) {
                    trySend(data)
                }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                val errorMsg = when {
                    response?.code == 503 -> "AI Backend setup required: GEMINI_API_KEY is not configured on the server."
                    response?.code == 404 -> "Cannot connect to LYRA backend endpoint ($baseUrl)."
                    t != null -> "Connection error: ${t.localizedMessage ?: "Network unavailable"}"
                    else -> "Network request failed (Code ${response?.code ?: 0})"
                }
                trySend(errorMsg)
                close(t)
            }

            override fun onClosed(eventSource: EventSource) {
                close()
            }
        }

        eventSource = eventSourceFactory.newEventSource(request, listener)

        awaitClose {
            eventSource.cancel()
        }
    }
}
