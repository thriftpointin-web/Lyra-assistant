package com.lyra.assistant.service.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

data class TtsVoiceInfo(
    val name: String,
    val locale: String,
    val isFemale: Boolean = false,
    val requiresNetwork: Boolean = false
)

class LyraTextToSpeech(
    context: Context,
    private val onInitComplete: (Boolean) -> Unit = {}
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceInfo>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceInfo>> = _availableVoices.asStateFlow()

    private var currentSpeed: Float = 1.0f
    private var currentPitch: Float = 1.0f
    private var isInitialized = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.language = Locale.ENGLISH

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })

            refreshVoices()
            onInitComplete(true)
        } else {
            isInitialized = false
            onInitComplete(false)
        }
    }

    fun refreshVoices() {
        if (!isInitialized || tts == null) return

        try {
            val voices = tts?.voices?.map { voice ->
                val name = voice.name
                val isFemale = name.contains("female", ignoreCase = true) ||
                        name.contains("en-us-x-sfg", ignoreCase = true) ||
                        name.contains("en-in-x-cfl", ignoreCase = true) ||
                        name.contains("hi-in-x-cfc", ignoreCase = true)
                TtsVoiceInfo(
                    name = voice.name,
                    locale = voice.locale.displayName,
                    isFemale = isFemale,
                    requiresNetwork = voice.isNetworkConnectionRequired
                )
            } ?: emptyList()

            _availableVoices.value = voices

            // Select default natural female voice if not explicitly chosen
            val preferredVoice = tts?.voices?.firstOrNull {
                it.name.contains("female", ignoreCase = true) ||
                it.name.contains("en-us-x-sfg", ignoreCase = true)
            }
            if (preferredVoice != null) {
                tts?.voice = preferredVoice
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSpeed(speed: Float) {
        currentSpeed = speed.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(currentSpeed)
    }

    fun setPitch(pitch: Float) {
        currentPitch = pitch.coerceIn(0.5f, 2.0f)
        tts?.setPitch(currentPitch)
    }

    fun setVoice(voiceName: String): Boolean {
        if (!isInitialized || tts == null) return false
        val matchingVoice = tts?.voices?.firstOrNull { it.name == voiceName }
        return if (matchingVoice != null) {
            tts?.voice = matchingVoice
            true
        } else {
            false
        }
    }

    /**
     * Speaks text immediately or enqueues it.
     * Starts TTS as soon as text arrives for low latency.
     */
    fun speak(text: String, queueMode: Int = TextToSpeech.QUEUE_FLUSH) {
        if (!isInitialized || tts == null || text.isBlank()) return

        val params = Bundle()
        val utteranceId = UUID.randomUUID().toString()

        tts?.speak(text, queueMode, params, utteranceId)
    }

    /**
     * Immediate audio interruption when the user taps or speaks.
     */
    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        }
        tts = null
    }
}
