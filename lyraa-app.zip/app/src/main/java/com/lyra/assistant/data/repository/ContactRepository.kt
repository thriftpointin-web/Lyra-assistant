package com.lyra.assistant.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.lyra.assistant.model.ContactItem

sealed class ContactSearchResult {
    data class SuccessSingle(val contact: ContactItem) : ContactSearchResult()
    data class SuccessMultiple(val contacts: List<ContactItem>) : ContactSearchResult()
    object NotFound : ContactSearchResult()
    object PermissionDenied : ContactSearchResult()
}

class ContactRepository(
    private val context: Context
) {
    fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Searches device contacts for the specified name.
     * Respects Android permissions and returns structured result.
     */
    fun findContacts(nameQuery: String): ContactSearchResult {
        if (!hasContactsPermission()) {
            return ContactSearchResult.PermissionDenied
        }

        val cleanedQuery = nameQuery.trim()
        if (cleanedQuery.isEmpty()) {
            return ContactSearchResult.NotFound
        }

        val contactsList = mutableListOf<ContactItem>()
        val contentResolver: ContentResolver = context.contentResolver

        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$cleanedQuery%")
        val sortOrder = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"

        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
            cursor?.let {
                val idIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val lookupIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY)

                while (it.moveToNext()) {
                    val id = if (idIndex != -1) it.getString(idIndex) else ""
                    val name = if (nameIndex != -1) it.getString(nameIndex) else "Unknown"
                    val number = if (numberIndex != -1) it.getString(numberIndex) else ""
                    val lookup = if (lookupIndex != -1) it.getString(lookupIndex) else null

                    // Avoid duplicate phone numbers for same contact
                    if (contactsList.none { existing -> existing.phoneNumber == number }) {
                        contactsList.add(
                            ContactItem(
                                id = id,
                                name = name,
                                phoneNumber = number,
                                lookupKey = lookup
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            cursor?.close()
        }

        return when {
            contactsList.isEmpty() -> ContactSearchResult.NotFound
            contactsList.size == 1 -> ContactSearchResult.SuccessSingle(contactsList.first())
            else -> ContactSearchResult.SuccessMultiple(contactsList)
        }
    }
}
