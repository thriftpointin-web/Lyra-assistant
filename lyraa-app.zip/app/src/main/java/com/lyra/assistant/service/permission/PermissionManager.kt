package com.lyra.assistant.service.permission

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat

enum class AppPermission(val permission: String, val title: String, val rationale: String) {
    MICROPHONE(
        android.Manifest.permission.RECORD_AUDIO,
        "Microphone Access",
        "LYRA needs microphone access to listen to your voice and voice commands."
    ),
    CONTACTS(
        android.Manifest.permission.READ_CONTACTS,
        "Contacts Access",
        "LYRA needs contacts access so you can say 'Call Ali' and find the correct contact on your phone."
    ),
    PHONE(
        android.Manifest.permission.CALL_PHONE,
        "Direct Phone Calls",
        "LYRA needs calling access to place direct phone calls once you confirm."
    )
}

class PermissionManager(private val context: Context) {

    fun isGranted(permission: AppPermission): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            permission.permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
